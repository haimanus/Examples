﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Helper class. any new commmon method will go here
/// Dated: 8/1/2019
/// by: Manoj Dominic
/// </summary>
/// 
namespace Common
{
    public  class Helper
    {


        //Below values has to be fetched from a config file or a database based on the final architecuture
        public const int PAYCHECK_AMOUNT = 2000;
        public const int NUMBER_OF_PAYCHECKS_IN_YEAR = 26;
        public const int COST_BENEFITS = 1000;

        public static int GetDiscountAmount(int benefitAmount, string name)
        {
            //discount % is hard coded now . This will have to fetch from a config or DB
            return name.ToLower().StartsWith("a") ? benefitAmount * 10 / 100 : 0; //% values will be taken from database in realtime implementation


        }
        public static int GetBenefitAmount(bool isEmployee)
        {
            //benefit amount is hard coded now . This will have to fetch from a config or DB
            return isEmployee ? 1000 : 500;//these values will be taken from database in realtime implementation
        }

    }
}
