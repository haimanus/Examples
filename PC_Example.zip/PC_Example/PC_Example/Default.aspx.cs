﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Common;
using System.Data;
using System.Diagnostics;

/// <summary>
/// Main page to enter the employee details and to do the calculations
/// Dated: 8/1/2019
/// by: Manoj Dominic
/// </summary>
namespace PC_Example
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!this.IsPostBack)
            {
                //setup the default values
                txtNumberOfPayChecks.Text = Helper.NUMBER_OF_PAYCHECKS_IN_YEAR.ToString();// in real implementation, this can come froma config or DB
                txtRegularPay.Text = Helper.PAYCHECK_AMOUNT.ToString();// in real implementation, this can come froma config or DB

                try
                {
                    //create a datatable 
                    DataTable dt = new DataTable();
                    dt.Columns.AddRange(new DataColumn[2] { new DataColumn("DependantName"), new DataColumn("DependantRelation") });
                    ViewState["EmployeeDependants"] = dt;// store in view state. in actual application scenario, it will be stored in DB
                    this.BindGrid();
                }
                catch (Exception ex)
                {
                    EventLog.WriteEntry("BC application", ex.Message);//do proper error logging here. This is only sample
                    throw ex;//
                }

            }

        }
        protected void Insert(object sender, EventArgs e)
        {

            try
            {

                //update grid
                //get data from view state. In real implmenetation, this can come from a DB
                DataTable dt = (DataTable)ViewState["EmployeeDependants"];

                //add rows to datatable
                dt.Rows.Add(txtDependantName.Text.Trim(), drpDependantRelation.SelectedValue);
                ViewState["EmployeeDependants"] = dt;

                //bind grid
                this.BindGrid();

                //clean up controls
                txtDependantName.Text = string.Empty;
                drpDependantRelation.SelectedValue = string.Empty;
                grdCostofBenefit.DataSource = null; // cleanup the calculation grid
                grdCostofBenefit.DataBind();
                lblTotalDeduction.Text = "";
                lblNetPay.Text = "";
            }
            catch (Exception ex)
            {
                EventLog.WriteEntry("BC application", ex.Message);//do proper error logging here.
                throw ex;//
            }

        }
        //common method to bind employee grid
        protected void BindGrid()
        {
            grdDependant.DataSource = (DataTable)ViewState["EmployeeDependants"];
            grdDependant.DataBind();
        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {

            int finalCostOfBenefits = 0;//initialize


            try
            {

                int NUMBER_OF_PAYCHECKS_IN_YEAR = Convert.ToInt32(txtNumberOfPayChecks.Text);//taking from text box to handle if any updates done to values
                int PAYCHECK_AMOUNT = Convert.ToInt32(txtRegularPay.Text);//taking from text box to handle if any updates done to values

                //create a data table to bind details-grid
                DataTable dtDetails = new DataTable();
                dtDetails.Columns.AddRange(new DataColumn[4] { new DataColumn("Name"), new DataColumn("Relationship"), new DataColumn("Cost of Benefit ($)"), new DataColumn("Discount ($)") });


                //get employee cost and discounts
                string employeeName = txtEmpName.Text;
                int employeeBenefitAmount = Helper.GetBenefitAmount(true); //benefit amount is hard coded inside the method
                int employeeDiscount = Helper.GetDiscountAmount(employeeBenefitAmount, employeeName);//discount % is hardcoded inside method
                finalCostOfBenefits = employeeBenefitAmount - employeeDiscount;

                //add employee details into the grid
                dtDetails.Rows.Add(txtEmpName.Text.Trim(), "(Self)", employeeBenefitAmount, employeeDiscount);

                //add dependant details ito the grid
                //for that get, the dependant details from view state
                DataTable dtDependant = (DataTable)ViewState["EmployeeDependants"];

                // loop throuhg each dependant details
                foreach (DataRow dr in dtDependant.Rows)
                {
                    int dependantCostOfBenefitAmount = Helper.GetBenefitAmount(false);
                    int dependantDiscount = Helper.GetDiscountAmount(dependantCostOfBenefitAmount, dr["DependantName"].ToString());

                    //add dependant details into the grid. Feed datatable first.
                    dtDetails.Rows.Add(dr["DependantName"], dr["DependantRelation"], dependantCostOfBenefitAmount, dependantDiscount);

                    //calculate the final cost of benefits
                    finalCostOfBenefits += dependantCostOfBenefitAmount - dependantDiscount;


                }

                //show total deduction
                lblTotalDeduction.Text = finalCostOfBenefits.ToString();

                //update grid with all deduction values
                grdCostofBenefit.DataSource = dtDetails;
                grdCostofBenefit.DataBind();//bind the final benefit grid  which shows all deductions

                //final calculation on net pay
                lblNetPay.Text = ((NUMBER_OF_PAYCHECKS_IN_YEAR * PAYCHECK_AMOUNT) - finalCostOfBenefits).ToString();//final net pay after deducting all benefit costs
            }
            catch (Exception ex)
            {
                EventLog.WriteEntry("BC application", ex.Message);//do proper error logging here.
                throw ex;//
            }



        }

        protected void grdDependant_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //delete operation in dependant-grid
            if (e.CommandName == "DeletePart")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                {
                    DataTable dt = (DataTable)ViewState["EmployeeDependants"];
                    dt.Rows.RemoveAt(index);//remove the item
                    BindGrid();//bind grid again
                }
                grdCostofBenefit.DataSource = null; // cleanup the calculation grid
                grdCostofBenefit.DataBind();
            }
        }


    }
}