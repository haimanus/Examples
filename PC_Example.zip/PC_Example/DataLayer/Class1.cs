﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
///added for future enhancement
/// Dated: 8/1/2019
/// by: Manoj Dominic
/// </summary>
namespace DataLayer
{
    public class Class1
    {
        //this need sto be expanded for database access.
    }
}
